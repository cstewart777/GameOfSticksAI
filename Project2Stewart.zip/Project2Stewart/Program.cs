﻿//Project2Stewart
//Collin Stewart
//March 2021
//Game of sticks! PvP PvAI PvSuperAI

using System;

namespace Project2Stewart
{
    class Program
    {
        static void Main(string[] args)
        {
            //Welcoming statement.
            Console.WriteLine("Welcome to the game of sticks!");

            //Prompt user for the number of sticks.
            Console.WriteLine("How many sticks are there on the table initially (10-100)?");

            //Read user input and check to see if number or not. 
            int numSticks = int.Parse(Console.ReadLine());


        }
    }
}
